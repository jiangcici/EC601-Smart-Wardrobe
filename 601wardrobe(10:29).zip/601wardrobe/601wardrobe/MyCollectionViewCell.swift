//
//  MyCollectionViewCell.swift
//  601wardrobe
//
//  Created by Tommy Zheng on 10/21/17.
//  Copyright © 2017 Tommy Zheng. All rights reserved.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myImageView: UIImageView!
}
